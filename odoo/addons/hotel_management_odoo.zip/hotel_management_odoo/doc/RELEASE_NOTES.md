## Module <hotel_management_odoo>

#### 11.08.2024
#### Version 18.0.1.0.0
#### ADD
- Initial commit for Hotel Management

#### 11.12.2024
#### Version 18.0.1.1.0
#### UPDT
- Fixed the issue Room reservation based on check in and check out date.

#### 19.12.2024
#### Version 18.0.1.1.1
#### UPDT
- The key name has been updated based on the latest addons.

#### 09.06.2025
#### Version 18.0.1.1.1
#### UPDT
- Added copy=false in some fields of room_booking model